from django.contrib import admin
from .models import LaunchCountry, Satellite
# Register your models here.
admin.site.register(LaunchCountry)
admin.site.register(Satellite)
